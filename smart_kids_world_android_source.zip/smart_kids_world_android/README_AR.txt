عالم الطفل الذكي - حزمة مصدر جاهزة للتحويل إلى تطبيق Android

محتويات الحزمة:
- www/index.html: نسخة التطبيق الأصلية (الإصدار السادس) داخل غلاف المشروع.
- www/assets/icon.svg: تصور الأيقونة الكرتونية التعليمية.
- package.json و capacitor.config.json: إعدادات مشروع Capacitor.

مهم:
هذه حزمة مصدر وليست APK جاهزاً. بيئة العمل الحالية لا تحتوي Android SDK أو Gradle، لذلك لم يتم بناء APK أو توقيعه.

خطوات البناء على حاسوب:
1) ثبّت Node.js LTS وAndroid Studio مع Android SDK.
2) فك ضغط الحزمة وافتح الطرفية داخل مجلد smart_kids_world_android.
3) نفّذ:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
4) في Android Studio انتظر اكتمال Gradle Sync، ثم اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
5) لنسخة توزيع رسمية، أنشئ مفتاح توقيع خاصاً بك واحتفظ بنسخة آمنة منه، ثم استخدم Generate Signed Bundle / APK.

اسم التطبيق: عالم الطفل الذكي
معرّف الحزمة: com.ostathnaama.smartkidsworld

ملاحظة: الأيقونة SVG المرفقة تصور مبدئي؛ يمكن تحويلها إلى أحجام PNG المطلوبة لأيقونات Android من خلال Image Asset Studio في Android Studio.
